
print("Hello world")
